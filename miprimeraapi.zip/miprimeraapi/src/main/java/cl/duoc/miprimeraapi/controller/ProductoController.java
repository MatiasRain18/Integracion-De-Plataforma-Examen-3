package cl.duoc.miprimeraapi.controller;

import cl.duoc.miprimeraapi.model.Producto;
import cl.duoc.miprimeraapi.model.repository.ProductoRepository;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    private ProductoRepository productoRepository;

    @Operation(summary = "Crear un nuevo producto")
    @PostMapping
    public Object crearProducto(@RequestBody Producto producto) {
        Producto existente = productoRepository.findByCodigoProducto(producto.getCodigoProducto());
        if (existente != null) {
            return "⚠️ El producto con código " + producto.getCodigoProducto() + " ya está registrado.";
        }
        return productoRepository.save(producto);
    }

    @Operation(summary = "Buscar producto por código")
    @GetMapping("/{codigo}")
    public Producto obtenerPorCodigo(@PathVariable String codigo) {
        return productoRepository.findByCodigoProducto(codigo);
    }

    @Operation(summary = "Buscar productos por nombre (contiene)")
    @GetMapping("/buscarNombre")
    public List<Producto> buscarPorNombre(@RequestParam String nombre) {
        return productoRepository.findByNombreContainingIgnoreCase(nombre);
    }

    @Operation(summary = "Buscar productos por categoría")
    @GetMapping("/categoria")
    public List<Producto> buscarPorCategoria(@RequestParam String categoria) {
        return productoRepository.findByCategoria(categoria);
    }

    @Operation(summary = "Buscar productos con bajo stock")
    @GetMapping("/bajoStock")
    public List<Producto> productosBajoStock(@RequestParam Integer stock) {
        return productoRepository.findByStockLessThan(stock);
    }
}
