package cl.duoc.miprimeraapi.controller;

import cl.duoc.miprimeraapi.model.MensajeContacto;
import cl.duoc.miprimeraapi.model.repository.MensajeContactoRepository;
import cl.duoc.miprimeraapi.model.repository.UsuarioRepository;
import cl.duoc.miprimeraapi.model.Usuario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;

@RestController
@RequestMapping("/mensajes")
public class MensajeContactoController {

    @Autowired
    private MensajeContactoRepository mensajeContactoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Operation(summary = "Guardar un mensaje de contacto")
    @PostMapping
    public MensajeContacto guardarMensaje(@RequestBody MensajeContacto mensaje) {
        return mensajeContactoRepository.save(mensaje);
    }

    @Operation(summary = "Obtener todos los mensajes de contacto (sin restricciones)")
    @GetMapping
    public List<MensajeContacto> obtenerTodosLosMensajes() {
        return mensajeContactoRepository.findAll();
    }

    @Operation(summary = "Obtener mensajes de contacto (solo para usuarios con rol interno)")
@GetMapping("/interno/{idUsuario}")
public List<MensajeContacto> obtenerMensajesSiInterno(@PathVariable Long idUsuario) {
    Usuario usuario = usuarioRepository.findById(idUsuario)
        .orElseThrow(() -> new ResponseStatusException(
            HttpStatus.NOT_FOUND, "Usuario con ID " + idUsuario + " no encontrado"));

    if (!"interno".equalsIgnoreCase(usuario.getRol())) {
        throw new ResponseStatusException(
            HttpStatus.FORBIDDEN,
            "Acceso denegado: el usuario con rol '" + usuario.getRol() + "' no tiene permiso para ver los mensajes."
        );
    }

    return mensajeContactoRepository.findAll();
}
}
