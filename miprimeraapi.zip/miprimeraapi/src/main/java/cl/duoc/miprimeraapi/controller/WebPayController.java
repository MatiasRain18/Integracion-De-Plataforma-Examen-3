package cl.duoc.miprimeraapi.controller;

import cl.duoc.miprimeraapi.model.TransaccionPago;
import cl.duoc.miprimeraapi.model.repository.TransaccionPagoRepository;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/webpay")
public class WebPayController {

    @Autowired
    private TransaccionPagoRepository transaccionPagoRepository;

    @Operation(summary = "Simular un pago pendiente con WebPay")
    @PostMapping("/pagar")
    public TransaccionPago simularPago(@RequestBody TransaccionPago pago) {
        pago.setEstado("PENDIENTE"); // ahora queda pendiente hasta confirmar
        pago.setFechaPago(LocalDateTime.now());
        return transaccionPagoRepository.save(pago);
    }

    @Operation(summary = "Obtener todas las transacciones de WebPay")
    @GetMapping("/pagar")
    public List<TransaccionPago> obtenerTransacciones() {
        return transaccionPagoRepository.findAll();
    }

    @Operation(summary = "Obtener transacciones por código de producto")
    @GetMapping("/pagar/{codigo}")
    public List<TransaccionPago> buscarPorCodigoProducto(@PathVariable String codigo) {
        return transaccionPagoRepository.findByCodigoProducto(codigo);
    }

    @Operation(summary = "Confirmar una transacción de pago por ID")
    @PatchMapping("/confirmar/{id}")
    public TransaccionPago confirmarPago(@PathVariable Long id) {
        Optional<TransaccionPago> pago = transaccionPagoRepository.findById(id);
        if (pago.isPresent()) {
            TransaccionPago transaccion = pago.get();
            transaccion.setEstado("APROBADO");
            return transaccionPagoRepository.save(transaccion);
        }
        throw new RuntimeException("Transacción no encontrada");
    }

    @Operation(summary = "Cancelar una transacción de pago por ID")
    @PatchMapping("/cancelar/{id}")
    public TransaccionPago cancelarPago(@PathVariable Long id) {
        Optional<TransaccionPago> pago = transaccionPagoRepository.findById(id);
        if (pago.isPresent()) {
            TransaccionPago transaccion = pago.get();
            transaccion.setEstado("CANCELADO");
            return transaccionPagoRepository.save(transaccion);
        }
        throw new RuntimeException("Transacción no encontrada");
    }

    @Operation(summary = "Ver estado de una transacción por ID")
    @GetMapping("/estado/{id}")
    public String obtenerEstado(@PathVariable Long id) {
        Optional<TransaccionPago> pago = transaccionPagoRepository.findById(id);
        if (pago.isPresent()) {
            return pago.get().getEstado();
        }
        return "Transacción no encontrada";
    }
}
