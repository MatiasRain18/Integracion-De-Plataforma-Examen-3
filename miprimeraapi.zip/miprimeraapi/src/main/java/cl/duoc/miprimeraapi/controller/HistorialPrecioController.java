package cl.duoc.miprimeraapi.controller;

import cl.duoc.miprimeraapi.model.HistorialPrecio;
import cl.duoc.miprimeraapi.model.repository.HistorialPrecioRepository;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/historial")
public class HistorialPrecioController {

    @Autowired
    private HistorialPrecioRepository historialPrecioRepository;

    @Operation(summary = "Obtener historial de precios por código de producto")
    @GetMapping("/{codigo}")
    public ResponseEntity<?> obtenerPorCodigo(@PathVariable String codigo) {
        List<HistorialPrecio> historial = historialPrecioRepository.findByCodigoProducto(codigo);
        if (historial.isEmpty()) {
            return ResponseEntity.status(404).body("No hay historial de precios para el producto con código: " + codigo);
        }
        return ResponseEntity.ok(historial);
    }

    @Operation(summary = "Agregar un nuevo registro al historial de precios")
    @PostMapping
    public ResponseEntity<?> agregar(@RequestBody HistorialPrecio historial) {
        if (historial.getCodigoProducto() == null || historial.getCodigoProducto().isBlank()) {
            return ResponseEntity.badRequest().body("Debe indicar el código del producto.");
        }
        if (historial.getValor() == null || historial.getValor() <= 0) {
            return ResponseEntity.badRequest().body("Debe ingresar un valor mayor a cero.");
        }

        // Si no se proporciona fecha, se asigna la actual
        if (historial.getFecha() == null) {
            historial.setFecha(LocalDateTime.now());
        }

        HistorialPrecio guardado = historialPrecioRepository.save(historial);
        return ResponseEntity.ok(guardado);
    }
}
