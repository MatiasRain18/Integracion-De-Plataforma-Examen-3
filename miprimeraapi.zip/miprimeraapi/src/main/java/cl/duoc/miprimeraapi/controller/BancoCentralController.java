package cl.duoc.miprimeraapi.controller;

import cl.duoc.miprimeraapi.model.ValorDolar;
import cl.duoc.miprimeraapi.model.TransaccionDolar;
import cl.duoc.miprimeraapi.model.repository.ValorDolarRepository;
import cl.duoc.miprimeraapi.model.repository.TransaccionDolarRepository;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/bancocentral")
public class BancoCentralController {

    @Autowired
    private ValorDolarRepository valorDolarRepository;

    @Autowired
    private TransaccionDolarRepository transaccionDolarRepository;

    // POST para guardar nuevo valor del dólar
    @Operation(summary = "Simular un nuevo valor del dólar y guardarlo")
    @PostMapping("/dolar")
    public ValorDolar guardarValorDolar() {
        ValorDolar nuevo = new ValorDolar();
        nuevo.setValor(generarValorDolar());
        nuevo.setFecha(LocalDateTime.now());
        return valorDolarRepository.save(nuevo);
    }

    // GET para obtener el último valor del dólar
    @Operation(summary = "Obtener el último valor guardado del dólar")
    @GetMapping("/dolar")
    public ValorDolar obtenerUltimoValor() {
        return valorDolarRepository.findTopByOrderByFechaDesc();
    }

    // ✅ POST para convertir dólares a pesos y guardar transacción
    @Operation(summary = "Simular una conversión de dólares a pesos y registrar la transacción")
    @PostMapping("/convertir")
    public TransaccionDolar convertirADolares(@RequestParam double montoDolares) {
        ValorDolar valorActual = valorDolarRepository.findTopByOrderByFechaDesc();

        double valorDolar = valorActual.getValor();
        double montoEnPesos = montoDolares * valorDolar;

        TransaccionDolar transaccion = new TransaccionDolar();
        transaccion.setValorDolar(valorDolar);
        transaccion.setMontoEnDolares(montoDolares);
        transaccion.setMontoEnPesos(montoEnPesos);
        transaccion.setFechaTransaccion(LocalDateTime.now());

        return transaccionDolarRepository.save(transaccion);
    }

    // ✅ GET para ver todas las transacciones registradas
    @Operation(summary = "Obtener todas las transacciones de conversión dólar a peso")
    @GetMapping("/transacciones")
    public List<TransaccionDolar> obtenerTodasLasTransacciones() {
        return transaccionDolarRepository.findAll();
    }

    private double generarValorDolar() {
        Random random = new Random();
        double valor = 860 + (random.nextDouble() * 40);
        return Math.round(valor * 100.0) / 100.0;
    }
}
